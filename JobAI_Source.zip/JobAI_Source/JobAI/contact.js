document.getElementById("contactForm").addEventListener("submit", function(event) {
  event.preventDefault();  

  const popup = document.getElementById("messagePopup");
  popup.style.display = "block";

  setTimeout(function() {
      popup.style.display = "none";  
      window.location.href = "mainpage.html"; 
  }, 2000);  
});
