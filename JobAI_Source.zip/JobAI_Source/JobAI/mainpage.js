window.addEventListener('load', function() {
  const firstName = localStorage.getItem('firstName');
  const lastName = localStorage.getItem('lastName');

  const userNameDisplay = document.getElementById('userNameDisplay');
  const loginBtn = document.getElementById('loginBtn');
  const registerBtn = document.getElementById('registerBtn');
  const logoutBtn = document.getElementById('logoutBtn');
  
  if (firstName && lastName) {
      userNameDisplay.innerText = `Welcome, ${firstName} ${lastName}`;

      loginBtn.style.display = 'none';
      registerBtn.style.display = 'none';

      logoutBtn.style.display = 'inline-block';

      logoutBtn.addEventListener('click', function() {
          localStorage.removeItem('firstName');
          localStorage.removeItem('lastName');
          localStorage.removeItem('password');
          
          window.location.href = 'login.html';
      });

  } else {
      userNameDisplay.innerText = '';
      logoutBtn.style.display = 'none';
  }

  const icons = document.querySelectorAll('.social-media img');
  icons.forEach((icon, index) => {
      setTimeout(() => {
          icon.style.transform = 'scale(1.1)';
      }, index * 200);

      setTimeout(() => {
          icon.style.transform = 'scale(1)';
      }, (index + 1) * 300);
  });
});

document.addEventListener('DOMContentLoaded', () => {
    const userName = localStorage.getItem('userName'); 

    if (userName) {
        document.getElementById('userNameDisplay').textContent = `Welcome, ${userName}!`;
        document.getElementById('loginBtn').style.display = 'none';
        document.getElementById('registerBtn').style.display = 'none';
        document.getElementById('logoutBtn').style.display = 'inline-block';
    } else {
        document.getElementById('userNameDisplay').textContent = '';
        document.getElementById('logoutBtn').style.display = 'none';
    }

    document.getElementById('logoutBtn').addEventListener('click', () => {
        localStorage.removeItem('userName'); 
        document.getElementById('userNameDisplay').textContent = '';
        document.getElementById('loginBtn').style.display = 'inline-block';
        document.getElementById('registerBtn').style.display = 'inline-block';
        document.getElementById('logoutBtn').style.display = 'none';
    });

    const sloganText = document.getElementById('slogan-text');
    let sloganArray = [
        "Find Your Perfect Job Match Effortlessly",
        "Unlock Your Potential with JobAI",
        "Your Dream Job is Just a Click Away",
        "Connect with Employers Seamlessly"
    ];
    
    let currentSloganIndex = 0;

    const changeSlogan = () => {
        currentSloganIndex = (currentSloganIndex + 1) % sloganArray.length;
        sloganText.textContent = sloganArray[currentSloganIndex];
        sloganText.classList.add('fade'); 
        setTimeout(() => {
            sloganText.classList.remove('fade'); 
        }, 1000); 
    };

    setInterval(changeSlogan, 3000); 
});

document.addEventListener('DOMContentLoaded', () => {
});