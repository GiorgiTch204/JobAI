window.addEventListener('load', function() {
  const firstName = localStorage.getItem('firstName');
  const lastName = localStorage.getItem('lastName');

  const userNameDisplay = document.getElementById('userNameDisplay');
  const loginBtn = document.getElementById('loginBtn');
  const registerBtn = document.getElementById('registerBtn');
  const logoutBtn = document.getElementById('logoutBtn');
  
  if (firstName && lastName) {
      userNameDisplay.innerText = `Welcome, ${firstName} ${lastName}`;

      loginBtn.style.display = 'none';
      registerBtn.style.display = 'none';

      logoutBtn.style.display = 'inline-block';

      logoutBtn.addEventListener('click', function() {
          localStorage.removeItem('firstName');
          localStorage.removeItem('lastName');
          localStorage.removeItem('password');
          
          window.location.href = 'login.html';
      });

  } else {
      userNameDisplay.innerText = '';
      logoutBtn.style.display = 'none';
  }

  const icons = document.querySelectorAll('.social-media img');
  icons.forEach((icon, index) => {
      setTimeout(() => {
          icon.style.transform = 'scale(1.1)';
      }, index * 200);

      setTimeout(() => {
          icon.style.transform = 'scale(1)';
      }, (index + 1) * 300);
  });
});
