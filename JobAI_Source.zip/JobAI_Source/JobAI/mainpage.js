function createCV() {
    alert("Create a CV feature coming soon!");
}

function uploadCV() {
    alert("Upload a CV feature coming soon!");
}


window.addEventListener('load', function() {
    const icons = document.querySelectorAll('.social-media img');
    
    icons.forEach((icon, index) => {
      setTimeout(() => {
        icon.style.transform = 'scale(1.1)';
      }, index * 200);  
      
      setTimeout(() => {
        icon.style.transform = 'scale(1)';
      }, (index + 1) * 300);
    });
  });
  

