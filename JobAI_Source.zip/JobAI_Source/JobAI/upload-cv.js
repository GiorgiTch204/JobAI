function uploadCV(event) {
    event.preventDefault(); 
    const fileInput = document.getElementById('cv-file');
    const progressBar = document.querySelector('.progress-bar-inner');
    const progressBarText = document.querySelector('.progress-bar-text');
    const errorMessage = document.querySelector('.error-message');
    
    const file = fileInput.files[0];
    
    if (!file) {
        errorMessage.textContent = 'Please select a file before uploading.';
        return;
    }
  
    errorMessage.textContent = '';
  
    let progress = 0;
    const uploadInterval = setInterval(() => {
        if (progress < 100) {
            progress += 10; 
            progressBar.style.width = progress + '%';
            progressBarText.textContent = `Uploading... ${progress}%`;
        } else {
            clearInterval(uploadInterval);
            progressBarText.textContent = 'Upload Complete!';
            
            setTimeout(() => {
                window.location.href = 'jobsforyou.html'; 
            }, 2000); 
        }
    }, 500); 
  }
  