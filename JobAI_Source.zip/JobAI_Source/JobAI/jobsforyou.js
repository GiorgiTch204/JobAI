document.addEventListener('DOMContentLoaded', () => {
  const jobListings = [
      { title: 'Software Developer', company: 'Tech Corp', location: 'New York, NY', type: 'Full-Time' },
      { title: 'Data Analyst', company: 'DataWorks', location: 'San Francisco, CA', type: 'Part-Time' },
      { title: 'Web Designer', company: 'Creative Studios', location: 'Remote', type: 'Freelance' },
      { title: 'AI Engineer', company: 'InnovateAI', location: 'Boston, MA', type: 'Full-Time' },
      { title: 'Database Administrator', company: 'SecureData', location: 'Chicago, IL', type: 'Full-Time' },
  ];

  const jobListingsContainer = document.getElementById('job-listings');

  jobListings.forEach(job => {
      const jobCard = document.createElement('div');
      jobCard.classList.add('job-card');

      jobCard.innerHTML = `
          <h3>${job.title}</h3>
          <p>Company: ${job.company}</p>
          <p>Location: ${job.location}</p>
          <p>Type: ${job.type}</p>
      `;

      jobListingsContainer.appendChild(jobCard);
  });
});

document.getElementById('logoutBtn').addEventListener('click', function(event) {
  event.preventDefault();
  
  localStorage.clear();
  sessionStorage.clear();
  
  document.cookie.split(";").forEach(function(c) { 
      document.cookie = c.trim().split("=")[0] + '=;expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/'; 
  });
  
  window.location.href = 'mainpage.html';
});
