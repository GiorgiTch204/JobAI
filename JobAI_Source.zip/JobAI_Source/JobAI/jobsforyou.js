const jobListings = [
  {
      title: "Software Developer",
      company: "Tech Solutions Inc.",
      workingHours: "40 hours/week",
      weeklyWage: "$1,200",
      annualWage: "$62,400",
      logo: "https://img.freepik.com/premium-vector/minimalist-logo-design-any-corporate-brand-business-company_1253202-77511.jpg" 
  },
  {
      title: "Data Analyst",
      company: "Data Insights Ltd.",
      workingHours: "40 hours/week",
      weeklyWage: "$1,000",
      annualWage: "$52,000",
      logo: ".vscode/JobAI/facebook.png"
  },
  {
      title: "Web Designer",
      company: "Creative Minds",
      workingHours: "35 hours/week",
      weeklyWage: "$950",
      annualWage: "$49,400",
      logo: ".vscode/JobAI/facebook.png"
  },
  {
      title: "Project Manager",
      company: "Global Projects Co.",
      workingHours: "40 hours/week",
      weeklyWage: "$1,500",
      annualWage: "$78,000",
      logo: ".vscode/JobAI/facebook.png"
  },
  {
      title: "UX/UI Designer",
      company: "Design Hub",
      workingHours: "40 hours/week",
      weeklyWage: "$1,100",
      annualWage: "$57,200",
      logo: ".vscode/JobAI/facebook.png"
  },
  {
      title: "Marketing Specialist",
      company: "Market Reach",
      workingHours: "40 hours/week",
      weeklyWage: "$1,000",
      annualWage: "$52,000",
      logo: ".vscode/JobAI/facebook.png"
  },
  {
      title: "System Administrator",
      company: "Tech Systems",
      workingHours: "40 hours/week",
      weeklyWage: "$1,200",
      annualWage: "$62,400",
      logo: ".vscode/JobAI/facebook.png"
  },
  {
      title: "Sales Executive",
      company: "SalesForce Ltd.",
      workingHours: "40 hours/week",
      weeklyWage: "$1,000",
      annualWage: "$52,000",
      logo: ".vscode/JobAI/facebook.png"
  },
  {
      title: "Content Writer",
      company: "Content Creators",
      workingHours: "35 hours/week",
      weeklyWage: "$800",
      annualWage: "$41,600",
      logo: "path/to/logo9.png"
  },
  {
      title: "Product Manager",
      company: "Innovate Co.",
      workingHours: "40 hours/week",
      weeklyWage: "$1,300",
      annualWage: "$67,600",
      logo: "path/to/logo10.png"
  },
  {
      title: "Graphic Designer",
      company: "Artistic Designs",
      workingHours: "35 hours/week",
      weeklyWage: "$900",
      annualWage: "$46,800",
      logo: "path/to/logo11.png"
  },
  {
      title: "Database Administrator",
      company: "Data Masters",
      workingHours: "40 hours/week",
      weeklyWage: "$1,200",
      annualWage: "$62,400",
      logo: "path/to/logo12.png"
  },
  {
      title: "HR Manager",
      company: "People Solutions",
      workingHours: "40 hours/week",
      weeklyWage: "$1,400",
      annualWage: "$72,800",
      logo: "path/to/logo13.png"
  },
  {
      title: "Mobile App Developer",
      company: "App Innovations",
      workingHours: "40 hours/week",
      weeklyWage: "$1,300",
      annualWage: "$67,600",
      logo: "path/to/logo14.png"
  },
  {
      title: "SEO Specialist",
      company: "SEO Experts",
      workingHours: "40 hours/week",
      weeklyWage: "$1,000",
      annualWage: "$52,000",
      logo: "path/to/logo15.png"
  },
  {
      title: "Business Analyst",
      company: "Analytica",
      workingHours: "40 hours/week",
      weeklyWage: "$1,200",
      annualWage: "$62,400",
      logo: "path/to/logo16.png"
  },
  {
      title: "Network Engineer",
      company: "Network Solutions",
      workingHours: "40 hours/week",
      weeklyWage: "$1,300",
      annualWage: "$67,600",
      logo: "path/to/logo17.png"
  },
  {
      title: "Technical Writer",
      company: "Tech Authors",
      workingHours: "35 hours/week",
      weeklyWage: "$850",
      annualWage: "$44,200",
      logo: "path/to/logo18.png"
  },
  {
      title: "Front-End Developer",
      company: "Web Creators",
      workingHours: "40 hours/week",
      weeklyWage: "$1,200",
      annualWage: "$62,400",
      logo: "path/to/logo19.png"
  },
  {
      title: "DevOps Engineer",
      company: "Ops Team",
      workingHours: "40 hours/week",
      weeklyWage: "$1,400",
      annualWage: "$72,800",
      logo: "path/to/logo20.png"
  }
];

function displayJobListings() {
  const jobListingsContainer = document.getElementById('job-listings');

  jobListings.forEach(job => {
      const jobCard = document.createElement('div');
      jobCard.className = 'job-card';

      jobCard.innerHTML = `
          <img src="${job.logo}" alt="${job.company} Logo" class="company-logo">
          <h3>${job.title}</h3>
          <p><strong>Company:</strong> ${job.company}</p>
          <p><strong>Working Hours:</strong> ${job.workingHours}</p>
          <p><strong>Weekly Wage:</strong> ${job.weeklyWage}</p>
          <p><strong>Annual Wage:</strong> ${job.annualWage}</p>
      `;

      jobListingsContainer.appendChild(jobCard);
  });
}

window.onload = displayJobListings;
