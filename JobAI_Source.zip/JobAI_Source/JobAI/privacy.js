document.addEventListener('DOMContentLoaded', () => {
  console.log("Privacy page loaded");
});
