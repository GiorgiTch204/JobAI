const passwordInput = document.getElementById('password');
const confirmPasswordInput = document.getElementById('confirmPassword');
const passwordStrengthIndicator = document.getElementById('passwordStrength');
const passwordConfirmationFeedback = document.getElementById('passwordConfirmationFeedback');

const checkPasswordStrength = (password) => {
    let strength = '';
    if (password.length < 6) {
        strength = 'weak';
    } else if (password.length < 12) {
        strength = 'medium';
    } else {
        strength = 'strong';
    }
    return strength;
};

const updatePasswordStrength = () => {
    const password = passwordInput.value;
    const strength = checkPasswordStrength(password);

    passwordStrengthIndicator.className = `strength-indicator ${strength}`;
};

const checkPasswordMatch = () => {
    const password = passwordInput.value;
    const confirmPassword = confirmPasswordInput.value;
    if (password === confirmPassword) {
        passwordConfirmationFeedback.className = 'confirmation-feedback match';
    } else {
        passwordConfirmationFeedback.className = 'confirmation-feedback no-match';
    }
};

passwordInput.addEventListener('input', updatePasswordStrength);
confirmPasswordInput.addEventListener('input', checkPasswordMatch);

const registrationForm = document.getElementById('registrationForm');
if (registrationForm) {
    registrationForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (password !== confirmPassword) {
            alert('Passwords do not match!');
        } else {
            alert('Registration successful!');
        }
    });
}
