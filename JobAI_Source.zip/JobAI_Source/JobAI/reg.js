const passwordInput = document.getElementById('password');
const confirmPasswordInput = document.getElementById('confirmPassword');
const passwordStrengthIndicator = document.getElementById('passwordStrength');
const passwordConfirmationFeedback = document.getElementById('passwordConfirmationFeedback');

const checkPasswordStrength = (password) => {
    let strength = '';
    if (password.length < 6) {
        strength = 'weak';
    } else if (password.length < 12) {
        strength = 'medium';
    } else {
        strength = 'strong';
    }
    return strength;
};

const updatePasswordStrength = () => {
    const password = passwordInput.value;
    const strength = checkPasswordStrength(password);
    passwordStrengthIndicator.className = `strength-indicator ${strength}`;
};

const checkPasswordMatch = () => {
    const password = passwordInput.value;
    const confirmPassword = confirmPasswordInput.value;
    if (password === confirmPassword) {
        passwordConfirmationFeedback.className = 'confirmation-feedback match';
        passwordConfirmationFeedback.textContent = 'Passwords match!';
    } else {
        passwordConfirmationFeedback.className = 'confirmation-feedback no-match';
        passwordConfirmationFeedback.textContent = 'Passwords do not match!';
    }
};

passwordInput.addEventListener('input', updatePasswordStrength);
confirmPasswordInput.addEventListener('input', checkPasswordMatch);

const registrationForm = document.getElementById('registrationForm');
if (registrationForm) {
    registrationForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const password = document.getElementById('password').value;
        const confirmPassword = document.getElementById('confirmPassword').value;

        if (password !== confirmPassword) {
            alert('Passwords do not match!');
        } else {
            localStorage.setItem('password', password); 

            alert('Registration successful! Redirecting to login page...');

            window.location.href = 'login.html';
        }
    });
}
