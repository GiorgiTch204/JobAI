const urlParams = new URLSearchParams(window.location.search);
const cvData = {
    firstName: urlParams.get('firstName'),
    lastName: urlParams.get('lastName'),
    email: urlParams.get('email'),
    phone: urlParams.get('phone'),
    profession: urlParams.get('profession'),
    skills: urlParams.get('skills'),
    about: urlParams.get('about')
};

const cvPreviewContent = document.getElementById('cv-preview-content');
cvPreviewContent.innerHTML = `
    <h3>${cvData.firstName} ${cvData.lastName}</h3>
    <p><strong>Email:</strong> ${cvData.email}</p>
    <p><strong>Phone:</strong> ${cvData.phone}</p>
    <p><strong>Profession:</strong> ${cvData.profession}</p>
    <p><strong>Skills:</strong></p>
    <ul>${cvData.skills.split(',').map(skill => `<li>${skill.trim()}</li>`).join('')}</ul>
    <p><strong>About Me:</strong></p>
    <p>${cvData.about}</p>

    
`;

document.getElementById('download-pdf').addEventListener('click', () => {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  const cvContent = `
      ${cvData.firstName} ${cvData.lastName}
      Email: ${cvData.email}
      Phone: ${cvData.phone}
      Profession: ${cvData.profession}
      Skills: ${cvData.skills}
      About Me: ${cvData.about}
  `;

  const lines = doc.splitTextToSize(cvContent, 180); 
  doc.text(lines, 10, 10); 

  doc.save('CV.pdf');
});


document.getElementById('download-pdf').addEventListener('click', () => {
    const { jsPDF } = window.jspdf; 
    const doc = new jsPDF();
    const margin = 10;

    doc.setFontSize(22);
    doc.text(`${cvData.firstName} ${cvData.lastName}`, margin, margin + 20);

    doc.setLineWidth(0.5);
    doc.line(margin, margin + 25, 200 - margin, margin + 25);

    doc.setFontSize(16);
    doc.text('Contact Information', margin, margin + 35);
    
    doc.setFontSize(12);
    doc.text(`Email: ${cvData.email}`, margin, margin + 45);
    doc.text(`Phone: ${cvData.phone}`, margin, margin + 50);

    doc.setFontSize(16);
    doc.text('Profession', margin, margin + 60);
    
    doc.setFontSize(12);
    doc.text(cvData.profession, margin, margin + 70);

    doc.setFontSize(16);
    doc.text('Skills', margin, margin + 80);
    
    const skills = cvData.skills.split(',').map(skill => skill.trim());
    skills.forEach((skill, index) => {
        doc.text(`- ${skill}`, margin, margin + 90 + (index * 5));
    });

    doc.setFontSize(16);
    doc.text('About Me', margin, margin + 90 + (skills.length * 5) + 10);
    
    const aboutLines = doc.splitTextToSize(cvData.about, 180);
    aboutLines.forEach((line, index) => {
        doc.text(line, margin, margin + 100 + (skills.length * 5) + 15 + (index * 5));
    });

    doc.save('CV.pdf');
});
