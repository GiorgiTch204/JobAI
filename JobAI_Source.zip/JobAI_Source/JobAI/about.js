document.addEventListener('DOMContentLoaded', () => {
  console.log("About page loaded");
});
