document.getElementById('accept-terms').addEventListener('click', () => {
  const message = document.getElementById('message');
  message.textContent = 'You have accepted the Terms of Service!';
  message.style.opacity = 1;
  setTimeout(() => {
      window.location.href = 'mainpage.html'; 
  }, 2000);
});

document.getElementById('decline-terms').addEventListener('click', () => {
  const message = document.getElementById('message');
  message.textContent = 'You have declined the Terms of Service. Please leave the site.';
  message.style.opacity = 1;
});
