document.addEventListener('DOMContentLoaded', () => {
  console.log("Terms page loaded");
});
