document.getElementById('cvForm').addEventListener('submit', function(event) {
  event.preventDefault(); 

  const firstName = document.getElementById('firstName').value;
  const lastName = document.getElementById('lastName').value;
  const email = document.getElementById('email').value;
  const phone = document.getElementById('phone').value;
  const profession = document.getElementById('profession').value;
  const skills = document.getElementById('skills').value;
  const about = document.getElementById('about').value;

  window.location.href = `cv-preview.html?firstName=${encodeURIComponent(firstName)}&lastName=${encodeURIComponent(lastName)}&email=${encodeURIComponent(email)}&phone=${encodeURIComponent(phone)}&profession=${encodeURIComponent(profession)}&skills=${encodeURIComponent(skills)}&about=${encodeURIComponent(about)}`;
});