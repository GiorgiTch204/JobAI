function createCV(event) {
  event.preventDefault();

  const firstName = document.getElementById('first-name').value;
  const lastName = document.getElementById('last-name').value;
  const field = document.getElementById('field-knowledge').value;
  const skills = document.getElementById('skills').value;
  const languages = document.getElementById('languages').value;
  const knowledgeLevel = document.getElementById('knowledge-level').value;
  const extraInfo = document.getElementById('extra-info').value;

  const newWindow = window.open('cv-preview.html');
  newWindow.onload = function () {
      newWindow.document.getElementById('first-name-display').innerText = firstName;
      newWindow.document.getElementById('last-name-display').innerText = lastName;
      newWindow.document.getElementById('field-display').innerText = field;
      newWindow.document.getElementById('skills-display').innerText = skills;
      newWindow.document.getElementById('languages-display').innerText = languages;
      newWindow.document.getElementById('knowledge-level-display').innerText = knowledgeLevel;
      newWindow.document.getElementById('extra-info-display').innerText = extraInfo;
  };
}

document.querySelector('.create-btn').addEventListener('click', function () {
  this.style.transform = 'translateY(-2px)';
  setTimeout(() => {
      this.style.transform = 'translateY(0px)';
  }, 100);
});


function createCV(event) {
  event.preventDefault(); 

  const firstName = document.getElementById('first-name').value;
  const lastName = document.getElementById('last-name').value;
  const fieldKnowledge = document.getElementById('field-knowledge').value;
  const skills = document.getElementById('skills').value;
  const languages = document.getElementById('languages').value;
  const knowledgeLevel = document.getElementById('knowledge-level').value;
  const extraInfo = document.getElementById('extra-info').value;

  window.location.href = `cv-preview.html?firstName=${encodeURIComponent(firstName)}&lastName=${encodeURIComponent(lastName)}&fieldKnowledge=${encodeURIComponent(fieldKnowledge)}&skills=${encodeURIComponent(skills)}&languages=${encodeURIComponent(languages)}&knowledgeLevel=${encodeURIComponent(knowledgeLevel)}&extraInfo=${encodeURIComponent(extraInfo)}`;
}
