function createCV(event) {
  event.preventDefault(); 
  const firstName = document.getElementById('first-name').value;
  const lastName = document.getElementById('last-name').value;
  const profession = document.getElementById('profession').value;
  const skills = document.getElementById('skills').value;
  const languages = Array.from(document.getElementById('languages').selectedOptions)
                         .map(option => option.text).join(', '); 
  const knowledgeLevel = document.getElementById('knowledge-level').value;
  const extraInfo = document.getElementById('extra-info').value;

  const newWindow = window.open('cv-preview.html');
  newWindow.onload = function () {
      newWindow.document.getElementById('first-name-display').innerText = firstName;
      newWindow.document.getElementById('last-name-display').innerText = lastName;
      newWindow.document.getElementById('field-display').innerText = profession;
      newWindow.document.getElementById('skills-display').innerText = skills;
      newWindow.document.getElementById('languages-display').innerText = languages;
      newWindow.document.getElementById('knowledge-level-display').innerText = knowledgeLevel;
      newWindow.document.getElementById('extra-info-display').innerText = extraInfo;
  };

  window.location.href = `cv-preview.html?firstName=${encodeURIComponent(firstName)}&lastName=${encodeURIComponent(lastName)}&profession=${encodeURIComponent(profession)}&skills=${encodeURIComponent(skills)}&languages=${encodeURIComponent(languages)}&knowledgeLevel=${encodeURIComponent(knowledgeLevel)}&extraInfo=${encodeURIComponent(extraInfo)}`;
}

document.querySelector('.create-btn').addEventListener('click', function () {
  this.style.transform = 'translateY(-2px)';
  setTimeout(() => {
      this.style.transform = 'translateY(0px)';
  }, 100);
});
